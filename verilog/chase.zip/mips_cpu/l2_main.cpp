#include "Vl2_tb.h"
#include "verilated.h"
#include "verilated_vpi.h"
#include "sdr_sdram.h"

#include <fstream>
#include <iostream>
#include <ctime>
#include <ratio>
#include <chrono>
#include <functional>

#define generalAssert(condition, message)                      \
    {                                                          \
        if (!(condition))                                      \
        {                                                      \
            std::cerr << message                               \
                      << " at line " << __LINE__ << std::endl; \
            return;                                            \
        }                                                      \
    }

#define assertEquals(a, b) \
    generalAssert(a == b, (int)a << " is not equal to " << (int)b)

#define assertLessthan(a, b) \
    generalAssert(a < b, (int)a << " is not less than " << (int)b)

#define assertFalse(a) \
    generalAssert(a == 0, (int)a << " is not false")

#define assertTrue(a) \
    generalAssert(a == 1, (int)a << " is not true")

void clk(Vl2_tb *dut);

size_t NANOS = 0;

void resetDut(Vl2_tb *dut)
{
    dut->clk = 0;
    dut->rst_n = 0;
    dut->w_control_base = 0;
    dut->w_control_length = 16;
    dut->w_control_go = 0;
    dut->w_user_data = 0;
    dut->w_user_we = 0;
    dut->r0_control_base = 0;
    dut->r0_control_length = 0;
    dut->r0_control_go = 0;
    dut->r0_user_re = 0;
    dut->r1_control_base = 0;
    dut->r1_control_length = 0;
    dut->r1_control_go = 0;
    dut->r1_user_re = 0;
    dut->writer_my_turn = 0;
    dut->reader_my_turn = 0;
    dut->reader_data[0] = 0;
    dut->reader_data[1] = 0;
    dut->reader_data[2] = 0;
    dut->reader_data[3] = 0;

    dut->l2_tagger_read_valid = 0;
    dut->l2_tagger_read_address = 0;
    dut->l2_tagger_write_valid = 0;
    dut->l2_tagger_write_address = 0;
    dut->l2_tagger_write_data[0] = 0;
    dut->l2_tagger_write_data[1] = 0;
    dut->l2_tagger_write_data[2] = 0;
    dut->l2_tagger_write_data[3] = 0;
    dut->l2_tagger_tx_read_data[0] = 0;
    dut->l2_tagger_tx_read_data[1] = 0;
    dut->l2_tagger_tx_read_data[2] = 0;
    dut->l2_tagger_tx_read_data[3] = 0;
    dut->l2_tagger_done_writing = 0;
    dut->l2_tagger_done_reading = 0;
    dut->l2_tagger_mem_read_data[0] = 0;
    dut->l2_tagger_mem_read_data[1] = 0;
    dut->l2_tagger_mem_read_data[2] = 0;
    dut->l2_tagger_mem_read_data[3] = 0;

    NANOS = 0;

    for (int i = 0; i < 10; i++)
    {
        clk(dut);
    }

    dut->rst_n = 1;
    dut->eval();

    for (int i = 0; i < 10; i++)
    {
        clk(dut);
    }

    dut->eval();
}

bool waitUntil(Vl2_tb *dut, std::function<bool()> waiter,
               int limit = 100)
{
    int counter = 0;
    while (!waiter())
    {
        clk(dut);
        counter++;
        if (counter > limit)
        {
            return false;
        }
    }
    return true;
}

void testWriterStartsNotRequesting(Vl2_tb *dut)
{
    resetDut(dut);
    assertFalse(dut->writer_wants_control);
}

void setupData(Vl2_tb *dut, uint32_t address, uint32_t a,
               uint32_t b, uint32_t c, uint32_t d)
{
    resetDut(dut);
    clk(dut);
    dut->w_control_base = address;
    dut->w_control_length = 16;
    dut->w_control_go = 1;
    dut->w_user_we = 0;
    clk(dut);

    // word 0
    dut->w_control_base = 0;
    dut->w_control_go = 0;
    dut->w_user_we = 1;
    dut->w_user_data = a;
    clk(dut);

    // word 1
    dut->w_control_base = 0;
    dut->w_control_go = 0;
    dut->w_user_we = 1;
    dut->w_user_data = b;
    clk(dut);

    // word 2
    dut->w_control_base = 0;
    dut->w_control_go = 0;
    dut->w_user_we = 1;
    dut->w_user_data = c;
    clk(dut);

    // word 3
    dut->w_control_base = 0;
    dut->w_control_go = 0;
    dut->w_user_we = 1;
    dut->w_user_data = d;
    clk(dut);
}

void testAfterRequestWriterWantsRequest(Vl2_tb *dut)
{
    resetDut(dut);
    clk(dut);
    dut->w_control_base = 0xDEAD0;
    dut->w_control_length = 16;
    dut->w_control_go = 1;
    clk(dut);
    assertFalse(dut->writer_wants_control);
    assertFalse(dut->writer_user_full);
    assertFalse(dut->writer_control_done);

    // word 0
    dut->w_control_base = 0;
    dut->w_control_go = 0;
    dut->w_user_we = 1;
    dut->w_user_data = 0x1337;
    clk(dut);
    assertFalse(dut->writer_wants_control);
    assertFalse(dut->writer_user_full);
    assertFalse(dut->writer_control_done);

    // word 1
    dut->w_control_base = 0;
    dut->w_control_go = 0;
    dut->w_user_we = 1;
    dut->w_user_data = 0x1338;
    clk(dut);
    assertFalse(dut->writer_wants_control);
    assertFalse(dut->writer_user_full);
    assertFalse(dut->writer_control_done);

    // word delay
    dut->w_control_base = 0;
    dut->w_control_go = 0;
    dut->w_user_we = 0;
    dut->w_user_data = 0xBAD;
    clk(dut);
    assertFalse(dut->writer_wants_control);
    assertFalse(dut->writer_user_full);
    assertFalse(dut->writer_control_done);

    // word 2
    dut->w_control_base = 0;
    dut->w_control_go = 0;
    dut->w_user_we = 1;
    dut->w_user_data = 0x1339;
    clk(dut);
    assertFalse(dut->writer_wants_control);
    assertFalse(dut->writer_user_full);
    assertFalse(dut->writer_control_done);

    // word 3
    dut->w_control_base = 0;
    dut->w_control_go = 0;
    dut->w_user_we = 1;
    dut->w_user_data = 0x1340;
    clk(dut);
    assertTrue(dut->writer_wants_control);
    assertFalse(dut->writer_user_full);
    assertTrue(dut->writer_control_done);
}

void testWriterOutputsDataAfterRequestingItsTurn(Vl2_tb *dut)
{
    setupData(dut, 0x1010, 1, 2, 3, 4);
    assertEquals(dut->writer_address, 0x1010);
    assertEquals(dut->writer_data[0], 1);
    assertEquals(dut->writer_data[1], 2);
    assertEquals(dut->writer_data[2], 3);
    assertEquals(dut->writer_data[3], 4);
}

void testMyTurnClearsRequestAndMakesReadyForNextAddress(Vl2_tb *dut)
{
    setupData(dut, 10, 1, 2, 3, 4);
    clk(dut);
    dut->writer_my_turn = 1;
    clk(dut);
    assertFalse(dut->writer_wants_control);
    setupData(dut, 20, 5, 6, 7, 8);
    assertEquals(dut->writer_address, 20);
    assertEquals(dut->writer_data[0], 5);
    assertEquals(dut->writer_data[1], 6);
    assertEquals(dut->writer_data[2], 7);
    assertEquals(dut->writer_data[3], 8);
}

void testRepeatedWriteSetsFull(Vl2_tb *dut)
{
    setupData(dut, 10, 1, 2, 3, 4);
    assertTrue(dut->writer_control_done);

    dut->w_control_base = 0xDEAD0;
    dut->w_control_length = 16;
    dut->w_control_go = 1;
    clk(dut);
    dut->w_control_go = 0;
    assertTrue(dut->writer_user_full);
    dut->w_control_base = 0;
    dut->writer_my_turn = 1;
    clk(dut);
    assertFalse(dut->writer_user_full);
    dut->w_user_we = 1;
    dut->w_user_data = 10;
    clk(dut);
    assertFalse(dut->writer_user_full);
    clk(dut);
    assertFalse(dut->writer_user_full);
    clk(dut);
    assertFalse(dut->writer_user_full);
    clk(dut);
    assertFalse(dut->writer_user_full);
    assertTrue(dut->writer_control_done);
    assertEquals(dut->writer_address, 0xDEAD0);
    assertEquals(dut->writer_data[0], 10);
}

void testReaderStartsNotRequesting(Vl2_tb *dut)
{
    resetDut(dut);
    assertFalse(dut->reader_wants_control);
}

void testAfterAddressReaderRequestsTurn(Vl2_tb *dut)
{
    resetDut(dut);
    dut->r0_control_base = 0xDEAD0;
    dut->r0_control_go = 1;
    dut->eval();
    assertEquals(dut->reader_address, 0xDEAD0);
    assertTrue(dut->reader_wants_control);
}

void testReaderKeepsAddressWhileNotTurn(Vl2_tb *dut)
{
    resetDut(dut);
    dut->r0_control_base = 0xDEAD0;
    dut->r0_control_go = 1;
    dut->eval();
    clk(dut);
    dut->r0_control_go = 1;
    dut->r0_control_base = 0;
    dut->eval();
    assertEquals(dut->reader_address, 0xDEAD0);
    assertTrue(dut->reader_wants_control);
    clk(dut);
    assertEquals(dut->reader_address, 0xDEAD0);
    assertTrue(dut->reader_wants_control);
}

void testReaderTransmitsDataStartingOnSameCycle(Vl2_tb *dut)
{
    resetDut(dut);
    dut->r0_control_base = 0xDEAD0;
    dut->r0_control_go = 1;
    clk(dut);
    assertFalse(dut->reader_user_avaliable)
    dut->reader_my_turn = 1;
    dut->reader_data[0] = 1337;
    dut->reader_data[1] = 1;
    dut->reader_data[2] = 2;
    dut->reader_data[3] = 3;
    dut->eval();
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 1337);
}

void testReaderAdvancesDataOnRead(Vl2_tb *dut)
{
    resetDut(dut);
    dut->r0_control_base = 0xDEAD0;
    dut->r0_control_go = 1;
    dut->reader_my_turn = 0;
    clk(dut);
    dut->r0_control_go = 0;
    assertFalse(dut->reader_user_avaliable)
    dut->reader_my_turn = 1;
    dut->reader_data[0] = 1337;
    dut->reader_data[1] = 1;
    dut->reader_data[2] = 2;
    dut->reader_data[3] = 3;
    dut->eval();
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 1337);
    assertFalse(dut->reader_wants_control);
    clk(dut);
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 1337);
    dut->r0_user_re = 1;
    clk(dut);
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 1);
    clk(dut);
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 2);
    clk(dut);
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 3);
    assertFalse(dut->reader_wants_control);
}

void testStallingReadeKeepsExistingData(Vl2_tb *dut)
{
    resetDut(dut);
    dut->r0_control_base = 0xDEAD0;
    dut->r0_control_go = 1;
    dut->reader_my_turn = 0;
    clk(dut);
    dut->r0_control_go = 0;
    assertFalse(dut->reader_user_avaliable)
    dut->reader_my_turn = 1;
    dut->reader_data[0] = 1337;
    dut->reader_data[1] = 1;
    dut->reader_data[2] = 2;
    dut->reader_data[3] = 3;
    dut->eval();
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 1337);
    assertFalse(dut->reader_wants_control);
    dut->r0_user_re = 1;
    clk(dut);
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 1);
    dut->r0_user_re = 0;
    clk(dut);
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 1);
    dut->r0_user_re = 1;
    clk(dut);
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 2);
    dut->r0_user_re = 0;
    clk(dut);
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 2);
    dut->r0_user_re = 1;
    clk(dut);
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 3);
    assertFalse(dut->reader_wants_control);
    clk(dut);
    assertFalse(dut->reader_user_avaliable);
}

void testReaderRepeatedAccessWorks(Vl2_tb *dut)
{
    resetDut(dut);
    dut->r0_control_base = 0xDEAD0;
    dut->r0_control_go = 1;
    dut->reader_my_turn = 0;
    clk(dut);
    dut->r0_control_go = 0;
    dut->reader_my_turn = 1;
    dut->reader_data[0] = 1337;
    dut->reader_data[1] = 1;
    dut->reader_data[2] = 2;
    dut->reader_data[3] = 3;
    dut->r0_user_re = 1;
    clk(dut);
    clk(dut);
    clk(dut);
    clk(dut);
    dut->r0_control_base = 0x13370;
    dut->r0_control_go = 1;
    dut->reader_my_turn = 0;
    clk(dut);
    assertTrue(dut->reader_wants_control);
    dut->reader_my_turn = 1;
    dut->reader_data[0] = 5;
    dut->reader_data[1] = 6;
    dut->reader_data[2] = 7;
    dut->reader_data[3] = 8;
    dut->eval();
    dut->r0_user_re = 1;
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 5);
    clk(dut);
    assertFalse(dut->reader_wants_control);
    dut->reader_my_turn = 0;
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 6);
    clk(dut);
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 7);
    clk(dut);
    assertTrue(dut->reader_user_avaliable);
    assertEquals(dut->reader_user_data, 8);
    clk(dut);
    assertFalse(dut->reader_user_avaliable);
}

// void write_cache(Vl2_tb *dut, uint32_t addr,
//     uint32_t a, uint32_t b, uint32_t c, uint32_t d)
// {
//     // dut->cache_set_writer_valid = 1;
//     dut->w_control_base = addr;
//     dut->reader_data[0] = a;
//     dut->reader_data[1] = b;
//     dut->reader_data[2] = c;
//     dut->reader_data[3] = d;
//     clk(dut);
//     // dut->cache_set_writer_valid = 0;
// }

void testInitialWriteRequiresRead(Vl2_tb *dut)
{
    resetDut(dut);
    assertFalse(dut->l2_tagger_we);
    assertFalse(dut->l2_tagger_write_go);
    assertFalse(dut->l2_tagger_read_go);

    dut->l2_tagger_read_address = 0xDAB0;
    dut->l2_tagger_read_valid = 1;
    assertFalse(dut->l2_tagger_read_go);
    clk(dut);
    assertTrue(dut->l2_tagger_read_go);
    assertEquals(dut->l2_tagger_address, 0xDAB0);
    assertFalse(dut->l2_tagger_write_go);
    assertFalse(dut->l2_tagger_read_done);
}

void testAfterResponseTaggerReadDone(Vl2_tb *dut){
    resetDut(dut);

    dut->l2_tagger_read_address = 4 * 4;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    clk(dut);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 0;
    dut->l2_tagger_tx_read_data[1] = 1;
    dut->l2_tagger_tx_read_data[2] = 2;
    dut->l2_tagger_tx_read_data[3] = 3;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertFalse(dut->l2_tagger_read_go);
    assertTrue(dut->l2_tagger_read_done);
    assertEquals(dut->l2_tagger_read_data[0], 0);
    assertEquals(dut->l2_tagger_read_data[1], 1);
    assertEquals(dut->l2_tagger_read_data[2], 2);
    assertEquals(dut->l2_tagger_read_data[3], 3);
    assertFalse(dut->l2_tagger_write_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 0);
    assertEquals(dut->l2_tagger_mem_write_data[1], 1);
    assertEquals(dut->l2_tagger_mem_write_data[2], 2);
    assertEquals(dut->l2_tagger_mem_write_data[3], 3);
    assertEquals(dut->l2_tagger_line_index, 0);
}

void testWriteConflictReadsAndWritesDuplicate(Vl2_tb *dut){
    resetDut(dut);

    dut->l2_tagger_read_address = 4 * 4;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    clk(dut);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 0;
    dut->l2_tagger_tx_read_data[1] = 1;
    dut->l2_tagger_tx_read_data[2] = 2;
    dut->l2_tagger_tx_read_data[3] = 3;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    clk(dut);
    dut->l2_tagger_read_address = 0x00;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    assertTrue(dut->l2_tagger_read_go);
    clk(dut);
    dut->l2_tagger_done_reading = 0;
    dut->eval();
    assertFalse(dut->l2_tagger_read_go);
    assertFalse(dut->l2_tagger_read_done);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 5;
    dut->l2_tagger_tx_read_data[1] = 6;
    dut->l2_tagger_tx_read_data[2] = 7;
    dut->l2_tagger_tx_read_data[3] = 8;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    assertEquals(dut->l2_tagger_read_data[0], 5);
    assertEquals(dut->l2_tagger_read_data[1], 6);
    assertEquals(dut->l2_tagger_read_data[2], 7);
    assertEquals(dut->l2_tagger_read_data[3], 8);
    assertFalse(dut->l2_tagger_write_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 5);
    assertEquals(dut->l2_tagger_mem_write_data[1], 6);
    assertEquals(dut->l2_tagger_mem_write_data[2], 7);
    assertEquals(dut->l2_tagger_mem_write_data[3], 8);
    assertEquals(dut->l2_tagger_line_index, 1);
}

void testReadOfFetchedAddressReadsFromCache(Vl2_tb *dut){
    resetDut(dut);

    dut->l2_tagger_read_address = 4 * 4;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    clk(dut);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 0;
    dut->l2_tagger_tx_read_data[1] = 1;
    dut->l2_tagger_tx_read_data[2] = 2;
    dut->l2_tagger_tx_read_data[3] = 3;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    clk(dut);
    dut->l2_tagger_read_address = 4*4;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    assertFalse(dut->l2_tagger_read_go);
    assertEquals(dut->l2_tagger_line_index, 0);
    clk(dut);

    assertFalse(dut->l2_tagger_read_go);
    assertTrue(dut->l2_tagger_read_done);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 0;
    dut->l2_tagger_tx_read_data[1] = 0;
    dut->l2_tagger_tx_read_data[2] = 0;
    dut->l2_tagger_tx_read_data[3] = 0;
    dut->l2_tagger_mem_read_data[0] = 0;
    dut->l2_tagger_mem_read_data[1] = 1;
    dut->l2_tagger_mem_read_data[2] = 2;
    dut->l2_tagger_mem_read_data[3] = 3;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    assertEquals(dut->l2_tagger_read_data[0], 0);
    assertEquals(dut->l2_tagger_read_data[1], 1);
    assertEquals(dut->l2_tagger_read_data[2], 2);
    assertEquals(dut->l2_tagger_read_data[3], 3);
    assertFalse(dut->l2_tagger_write_go);
    assertFalse(dut->l2_tagger_we);
}

#define doReadAndFill(dut, address, data_start) doReadAndFillImpl(dut, address, data_start, __LINE__)

void doReadAndFillImpl(Vl2_tb* dut, int address, int data_start, int line){
    dut->l2_tagger_read_address = address;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    clk(dut);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = data_start;
    dut->l2_tagger_tx_read_data[1] = data_start+1;
    dut->l2_tagger_tx_read_data[2] = data_start+2;
    dut->l2_tagger_tx_read_data[3] = data_start+3;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    // assertTrue(dut->l2_tagger_read_done);
    if(!dut->l2_tagger_read_done){
        std::cerr << "Not done reading in readAndFill at line " << line << std::endl;
    }
    clk(dut);
}

void testCapacityReadOverwritesOldest(Vl2_tb *dut){
    resetDut(dut);

    doReadAndFill(dut, 0, 0);
    doReadAndFill(dut, 4*4, 4);
    doReadAndFill(dut, 4*8, 8);
    doReadAndFill(dut, 4*12, 12);

    dut->l2_tagger_read_address = 16 * 4;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    clk(dut);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 16;
    dut->l2_tagger_tx_read_data[1] = 17;
    dut->l2_tagger_tx_read_data[2] = 18;
    dut->l2_tagger_tx_read_data[3] = 19;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    assertEquals(dut->l2_tagger_read_data[0], 16);
    assertEquals(dut->l2_tagger_read_data[1], 17);
    assertEquals(dut->l2_tagger_read_data[2], 18);
    assertEquals(dut->l2_tagger_read_data[3], 19);
    assertFalse(dut->l2_tagger_write_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 16);
    assertEquals(dut->l2_tagger_mem_write_data[1], 17);
    assertEquals(dut->l2_tagger_mem_write_data[2], 18);
    assertEquals(dut->l2_tagger_mem_write_data[3], 19);
    assertEquals(dut->l2_tagger_line_index, 0);
    clk(dut);
    dut->l2_tagger_read_address = 20 * 4;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    clk(dut);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 20;
    dut->l2_tagger_tx_read_data[1] = 21;
    dut->l2_tagger_tx_read_data[2] = 22;
    dut->l2_tagger_tx_read_data[3] = 23;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    assertEquals(dut->l2_tagger_read_data[0], 20);
    assertEquals(dut->l2_tagger_read_data[1], 21);
    assertEquals(dut->l2_tagger_read_data[2], 22);
    assertEquals(dut->l2_tagger_read_data[3], 23);
    assertFalse(dut->l2_tagger_write_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 20);
    assertEquals(dut->l2_tagger_mem_write_data[1], 21);
    assertEquals(dut->l2_tagger_mem_write_data[2], 22);
    assertEquals(dut->l2_tagger_mem_write_data[3], 23);
    assertEquals(dut->l2_tagger_line_index, 1);
    clk(dut);
}

void testHitReadMarksAsMoreReccent(Vl2_tb *dut){
    resetDut(dut);

    doReadAndFill(dut, 0, 0);
    doReadAndFill(dut, 4*4, 4);
    doReadAndFill(dut, 4*8, 8);
    doReadAndFill(dut, 4*12, 12);

    dut->l2_tagger_read_address = 0;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    assertEquals(dut->l2_tagger_line_index, 0);
    clk(dut);
    assertTrue(dut->l2_tagger_read_done);
    assertFalse(dut->l2_tagger_write_go);
    assertFalse(dut->l2_tagger_we);
    clk(dut);
    dut->l2_tagger_read_address = 20 * 4;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    clk(dut);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 20;
    dut->l2_tagger_tx_read_data[1] = 21;
    dut->l2_tagger_tx_read_data[2] = 22;
    dut->l2_tagger_tx_read_data[3] = 23;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    assertEquals(dut->l2_tagger_read_data[0], 20);
    assertEquals(dut->l2_tagger_read_data[1], 21);
    assertEquals(dut->l2_tagger_read_data[2], 22);
    assertEquals(dut->l2_tagger_read_data[3], 23);
    assertFalse(dut->l2_tagger_write_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 20);
    assertEquals(dut->l2_tagger_mem_write_data[1], 21);
    assertEquals(dut->l2_tagger_mem_write_data[2], 22);
    assertEquals(dut->l2_tagger_mem_write_data[3], 23);
    assertEquals(dut->l2_tagger_line_index, 1);
    clk(dut);
}

void testMidtermReadDoesNotTrickCounts(Vl2_tb *dut){
    resetDut(dut);

    doReadAndFill(dut, 0, 0);
    doReadAndFill(dut, 4*4, 4);
    doReadAndFill(dut, 4*8, 8);
    dut->l2_tagger_read_address = 4*8;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    assertEquals(dut->l2_tagger_line_index, 2);
    clk(dut);
    assertTrue(dut->l2_tagger_read_done);
    assertFalse(dut->l2_tagger_write_go);
    assertFalse(dut->l2_tagger_we);
    clk(dut);
    doReadAndFill(dut, 4*12, 12);

    dut->l2_tagger_read_address = 16 * 4;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    clk(dut);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 16;
    dut->l2_tagger_tx_read_data[1] = 17;
    dut->l2_tagger_tx_read_data[2] = 18;
    dut->l2_tagger_tx_read_data[3] = 19;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    assertEquals(dut->l2_tagger_read_data[0], 16);
    assertEquals(dut->l2_tagger_read_data[1], 17);
    assertEquals(dut->l2_tagger_read_data[2], 18);
    assertEquals(dut->l2_tagger_read_data[3], 19);
    assertFalse(dut->l2_tagger_write_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 16);
    assertEquals(dut->l2_tagger_mem_write_data[1], 17);
    assertEquals(dut->l2_tagger_mem_write_data[2], 18);
    assertEquals(dut->l2_tagger_mem_write_data[3], 19);
    assertEquals(dut->l2_tagger_line_index, 0);
    clk(dut);
    dut->l2_tagger_read_address = 20 * 4;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    clk(dut);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 20;
    dut->l2_tagger_tx_read_data[1] = 21;
    dut->l2_tagger_tx_read_data[2] = 22;
    dut->l2_tagger_tx_read_data[3] = 23;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    assertEquals(dut->l2_tagger_read_data[0], 20);
    assertEquals(dut->l2_tagger_read_data[1], 21);
    assertEquals(dut->l2_tagger_read_data[2], 22);
    assertEquals(dut->l2_tagger_read_data[3], 23);
    assertFalse(dut->l2_tagger_write_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 20);
    assertEquals(dut->l2_tagger_mem_write_data[1], 21);
    assertEquals(dut->l2_tagger_mem_write_data[2], 22);
    assertEquals(dut->l2_tagger_mem_write_data[3], 23);
    assertEquals(dut->l2_tagger_line_index, 1);
    clk(dut);
}

void readThenWriteOverridesDataInSameLine(Vl2_tb* dut){
    resetDut(dut);

    doReadAndFill(dut, 0, 0);
    dut->l2_tagger_read_valid = 0;
    dut->l2_tagger_write_valid = 1;
    dut->l2_tagger_write_address = 0;
    dut->l2_tagger_write_data[0] = 5;
    dut->l2_tagger_write_data[1] = 6;
    dut->l2_tagger_write_data[2] = 7;
    dut->l2_tagger_write_data[3] = 8;
    clk(dut);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 5);
    assertEquals(dut->l2_tagger_mem_write_data[1], 6);
    assertEquals(dut->l2_tagger_mem_write_data[2], 7);
    assertEquals(dut->l2_tagger_mem_write_data[3], 8);
    assertEquals(dut->l2_tagger_line_index, 0);
}

void testHitWriteMarksAsMoreReccent(Vl2_tb *dut){
    resetDut(dut);

    doReadAndFill(dut, 0, 0);
    doReadAndFill(dut, 4*4, 4);
    doReadAndFill(dut, 4*8, 8);
    doReadAndFill(dut, 4*12, 12);

    dut->l2_tagger_read_address = 1337;
    dut->l2_tagger_read_valid = 0;
    dut->l2_tagger_write_valid = 1;
    dut->l2_tagger_write_address = 0;
    dut->l2_tagger_write_data[0] = 5;
    dut->l2_tagger_write_data[1] = 6;
    dut->l2_tagger_write_data[2] = 7;
    dut->l2_tagger_write_data[3] = 8;
    clk(dut);
    dut->l2_tagger_write_valid = 0;
    clk(dut);
    dut->l2_tagger_read_address = 20 * 4;
    dut->l2_tagger_read_valid = 1;
    dut->eval();
    clk(dut);
    clk(dut);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 20;
    dut->l2_tagger_tx_read_data[1] = 21;
    dut->l2_tagger_tx_read_data[2] = 22;
    dut->l2_tagger_tx_read_data[3] = 23;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    assertEquals(dut->l2_tagger_read_data[0], 20);
    assertEquals(dut->l2_tagger_read_data[1], 21);
    assertEquals(dut->l2_tagger_read_data[2], 22);
    assertEquals(dut->l2_tagger_read_data[3], 23);
    assertFalse(dut->l2_tagger_write_go);
    assertFalse(dut->l2_tagger_read_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 20);
    assertEquals(dut->l2_tagger_mem_write_data[1], 21);
    assertEquals(dut->l2_tagger_mem_write_data[2], 22);
    assertEquals(dut->l2_tagger_mem_write_data[3], 23);
    assertEquals(dut->l2_tagger_line_index, 1);
    clk(dut);
}

void testBlankWriteOverridesWithoutFetch(Vl2_tb *dut){
    resetDut(dut);

    dut->l2_tagger_read_address = 1337;
    dut->l2_tagger_read_valid = 0;
    dut->l2_tagger_write_valid = 1;
    dut->l2_tagger_write_address = 0;
    dut->l2_tagger_write_data[0] = 5;
    dut->l2_tagger_write_data[1] = 6;
    dut->l2_tagger_write_data[2] = 7;
    dut->l2_tagger_write_data[3] = 8;
    clk(dut);
    dut->l2_tagger_write_valid = 0;
    assertFalse(dut->l2_tagger_write_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 5);
    assertEquals(dut->l2_tagger_mem_write_data[1], 6);
    assertEquals(dut->l2_tagger_mem_write_data[2], 7);
    assertEquals(dut->l2_tagger_mem_write_data[3], 8);
    assertEquals(dut->l2_tagger_line_index, 0);
    clk(dut);
    dut->l2_tagger_read_address = 20 * 4;
    dut->l2_tagger_read_valid = 1;
    dut->eval();
    clk(dut);
    clk(dut);
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 20;
    dut->l2_tagger_tx_read_data[1] = 21;
    dut->l2_tagger_tx_read_data[2] = 22;
    dut->l2_tagger_tx_read_data[3] = 23;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    assertEquals(dut->l2_tagger_read_data[0], 20);
    assertEquals(dut->l2_tagger_read_data[1], 21);
    assertEquals(dut->l2_tagger_read_data[2], 22);
    assertEquals(dut->l2_tagger_read_data[3], 23);
    assertFalse(dut->l2_tagger_write_go);
    assertFalse(dut->l2_tagger_read_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 20);
    assertEquals(dut->l2_tagger_mem_write_data[1], 21);
    assertEquals(dut->l2_tagger_mem_write_data[2], 22);
    assertEquals(dut->l2_tagger_mem_write_data[3], 23);
    assertEquals(dut->l2_tagger_line_index, 1);
    clk(dut);
}

void testWritingAllowsForReadLater(Vl2_tb *dut){
    resetDut(dut);

    dut->l2_tagger_read_address = 1337;
    dut->l2_tagger_read_valid = 0;
    dut->l2_tagger_write_valid = 1;
    dut->l2_tagger_write_address = 4*4;
    dut->l2_tagger_write_data[0] = 5;
    dut->l2_tagger_write_data[1] = 6;
    dut->l2_tagger_write_data[2] = 7;
    dut->l2_tagger_write_data[3] = 8;
    clk(dut);
    dut->l2_tagger_write_valid = 0;
    assertFalse(dut->l2_tagger_write_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 5);
    assertEquals(dut->l2_tagger_mem_write_data[1], 6);
    assertEquals(dut->l2_tagger_mem_write_data[2], 7);
    assertEquals(dut->l2_tagger_mem_write_data[3], 8);
    assertEquals(dut->l2_tagger_line_index, 0);
    clk(dut);
    dut->l2_tagger_read_address = 4 * 4;
    dut->l2_tagger_read_valid = 1;
    dut->eval();
    clk(dut);
    assertFalse(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_line_index, 0);
}

void testWrittenLinesFlushedOnConflict(Vl2_tb *dut){
    resetDut(dut);

    dut->l2_tagger_read_address = 1337;
    dut->l2_tagger_read_valid = 0;
    dut->l2_tagger_write_valid = 1;
    dut->l2_tagger_write_address = 4*4;
    dut->l2_tagger_write_data[0] = 5;
    dut->l2_tagger_write_data[1] = 6;
    dut->l2_tagger_write_data[2] = 7;
    dut->l2_tagger_write_data[3] = 8;
    clk(dut);
    dut->l2_tagger_write_valid = 0;
    assertEquals(dut->l2_tagger_line_index, 0);
    clk(dut);

    doReadAndFill(dut, 0, 0);
    doReadAndFill(dut, 8*4, 8);
    doReadAndFill(dut, 12*4, 12);

    dut->l2_tagger_read_address = 16 * 4;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    
    // check to make sure we are flushing
    assertFalse(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_line_index, 0);
    assertFalse(dut->l2_tagger_write_go);
    clk(dut);
    dut->l2_tagger_mem_read_data[0] = 0;
    dut->l2_tagger_mem_read_data[1] = 1;
    dut->l2_tagger_mem_read_data[2] = 2;
    dut->l2_tagger_mem_read_data[3] = 3;
    dut->eval();
    assertTrue(dut->l2_tagger_write_go);
    assertEquals(dut->l2_tagger_tx_write_data[0], 0);
    assertEquals(dut->l2_tagger_tx_write_data[1], 1);
    assertEquals(dut->l2_tagger_tx_write_data[2], 2);
    assertEquals(dut->l2_tagger_tx_write_data[3], 3);
    clk(dut);
    assertFalse(dut->l2_tagger_write_go);

    // done flushing now we should be refilling
    dut->l2_tagger_done_writing = 1;
    dut->eval();
    assertTrue(dut->l2_tagger_read_go);
    assertEquals(dut->l2_tagger_address, 16*4);
    assertFalse(dut->l2_tagger_write_go);
    assertFalse(dut->l2_tagger_read_done);
    clk(dut);
    assertFalse(dut->l2_tagger_read_go);
    assertFalse(dut->l2_tagger_write_go);
    
    dut->l2_tagger_done_reading = 1;
    dut->l2_tagger_tx_read_data[0] = 20;
    dut->l2_tagger_tx_read_data[1] = 21;
    dut->l2_tagger_tx_read_data[2] = 22;
    dut->l2_tagger_tx_read_data[3] = 23;
    dut->l2_tagger_read_valid = 0;
    dut->eval();
    assertTrue(dut->l2_tagger_read_done);
    assertEquals(dut->l2_tagger_read_data[0], 20);
    assertEquals(dut->l2_tagger_read_data[1], 21);
    assertEquals(dut->l2_tagger_read_data[2], 22);
    assertEquals(dut->l2_tagger_read_data[3], 23);
    assertFalse(dut->l2_tagger_write_go);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_mem_write_data[0], 20);
    assertEquals(dut->l2_tagger_mem_write_data[1], 21);
    assertEquals(dut->l2_tagger_mem_write_data[2], 22);
    assertEquals(dut->l2_tagger_mem_write_data[3], 23);
    assertEquals(dut->l2_tagger_line_index, 0);


    // std::cout << "Make sure that we go through ready, delay, flush, refill" << std::endl;
}

void testWrittenLinesFlushedOnConflictWrite(Vl2_tb *dut){
    resetDut(dut);

    dut->l2_tagger_read_address = 1337;
    dut->l2_tagger_read_valid = 0;
    dut->l2_tagger_write_valid = 1;
    dut->l2_tagger_write_address = 4*4;
    dut->l2_tagger_write_data[0] = 5;
    dut->l2_tagger_write_data[1] = 6;
    dut->l2_tagger_write_data[2] = 7;
    dut->l2_tagger_write_data[3] = 8;
    clk(dut);
    dut->l2_tagger_write_valid = 0;
    assertEquals(dut->l2_tagger_line_index, 0);
    clk(dut);

    doReadAndFill(dut, 0, 0);
    doReadAndFill(dut, 8*4, 8);
    doReadAndFill(dut, 12*4, 12);

    dut->l2_tagger_write_address = 16 * 4;
    dut->l2_tagger_read_valid = 0;
    dut->l2_tagger_write_valid = 1;
    dut->l2_tagger_write_data[0] = 5;
    dut->l2_tagger_write_data[1] = 6;
    dut->l2_tagger_write_data[2] = 7;
    dut->l2_tagger_write_data[3] = 8;
    clk(dut);
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_line_index, 0);
    assertFalse(dut->l2_tagger_write_go);
    clk(dut);
    dut->l2_tagger_mem_read_data[0] = 0;
    dut->l2_tagger_mem_read_data[1] = 1;
    dut->l2_tagger_mem_read_data[2] = 2;
    dut->l2_tagger_mem_read_data[3] = 3;
    dut->eval();
    // check to make sure we are flushing
    assertFalse(dut->l2_tagger_we);
    // assertEquals(dut->l2_tagger_line_index, 0);
    assertTrue(dut->l2_tagger_write_go);
    assertEquals(dut->l2_tagger_tx_write_data[0], 0);
    assertEquals(dut->l2_tagger_tx_write_data[1], 1);
    assertEquals(dut->l2_tagger_tx_write_data[2], 2);
    assertEquals(dut->l2_tagger_tx_write_data[3], 3);
    assertEquals(dut->l2_tagger_mem_write_data[0], 5);
    assertEquals(dut->l2_tagger_mem_write_data[1], 6);
    assertEquals(dut->l2_tagger_mem_write_data[2], 7);
    assertEquals(dut->l2_tagger_mem_write_data[3], 8);
    clk(dut);
    dut->l2_tagger_write_valid = 0;
    assertFalse(dut->l2_tagger_write_go);
    assertFalse(dut->l2_tagger_we);

    // done flushing now we should be refilling
    dut->l2_tagger_done_writing = 1;
    dut->eval();
    assertFalse(dut->l2_tagger_write_go);
    clk(dut);

    // std::cout << "Make sure that we go through ready, delay, flush, refill" << std::endl;
}

void testReadAfterWriteDoesNotMarkAsNonDirty(Vl2_tb* dut){
    std::cout << "Starting test" << std::endl;
    resetDut(dut);
    std::cout << "Done reset" << std::endl;
    clk(dut);
    clk(dut);
    clk(dut);
    clk(dut);
    std::cout << "empty clock done" << std::endl;

    dut->l2_tagger_read_address = 1337;
    dut->l2_tagger_read_valid = 0;
    dut->l2_tagger_write_valid = 1;
    dut->l2_tagger_write_address = 4*4;
    dut->l2_tagger_write_data[0] = 5;
    dut->l2_tagger_write_data[1] = 6;
    dut->l2_tagger_write_data[2] = 7;
    dut->l2_tagger_write_data[3] = 8;
    clk(dut);
    dut->l2_tagger_write_valid = 0;
    assertEquals(dut->l2_tagger_line_index, 0);
    clk(dut);
    std::cout << "Starting write blocks" << std::endl;

    doReadAndFill(dut, 0, 0);
    doReadAndFill(dut, 8*4, 8);
    doReadAndFill(dut, 12*4, 12);

    dut->l2_tagger_read_address = 4*4;
    dut->l2_tagger_read_valid = 1;
    clk(dut);
    assertFalse(dut->l2_tagger_write_go);
    assertFalse(dut->l2_tagger_read_go);
    assertEquals(dut->l2_tagger_line_index, 0);
    clk(dut);
    clk(dut);

    doReadAndFill(dut, 0, 0);
    doReadAndFill(dut, 8*4, 8);
    doReadAndFill(dut, 12*4, 12);

    dut->l2_tagger_write_address = 16 * 4;
    dut->l2_tagger_read_valid = 0;
    dut->l2_tagger_write_valid = 1;
    dut->l2_tagger_write_data[0] = 5;
    dut->l2_tagger_write_data[1] = 6;
    dut->l2_tagger_write_data[2] = 7;
    dut->l2_tagger_write_data[3] = 8;
    clk(dut);
    
    // check to make sure we are flushing
    assertTrue(dut->l2_tagger_we);
    assertEquals(dut->l2_tagger_line_index, 0);
    assertEquals(dut->l2_tagger_mem_write_data[0], 5);
    assertEquals(dut->l2_tagger_mem_write_data[1], 6);
    assertEquals(dut->l2_tagger_mem_write_data[2], 7);
    assertEquals(dut->l2_tagger_mem_write_data[3], 8);
    assertFalse(dut->l2_tagger_write_go);
    clk(dut);
    dut->l2_tagger_mem_read_data[0] = 0;
    dut->l2_tagger_mem_read_data[1] = 1;
    dut->l2_tagger_mem_read_data[2] = 2;
    dut->l2_tagger_mem_read_data[3] = 3;
    dut->eval();
    assertEquals(dut->l2_tagger_tx_write_data[0], 0);
    assertEquals(dut->l2_tagger_tx_write_data[1], 1);
    assertEquals(dut->l2_tagger_tx_write_data[2], 2);
    assertEquals(dut->l2_tagger_tx_write_data[3], 3);
    assertTrue(dut->l2_tagger_write_go);

    assertFalse(dut->l2_tagger_we);
    clk(dut);

    // done flushing now we should be refilling
    dut->l2_tagger_done_writing = 1;
    dut->eval();
    assertFalse(dut->l2_tagger_write_go);

    // std::cout << "Make sure that we go through ready, delay, flush, refill" << std::endl;
}

int main(int argc, char **argv, char **env)
{
    Verilated::commandArgs(argc, argv);

    std::chrono::high_resolution_clock::time_point start_time = std::chrono::high_resolution_clock::now();

    Vl2_tb *top = new Vl2_tb;
    testWriterStartsNotRequesting(top);
    testAfterRequestWriterWantsRequest(top);
    testWriterOutputsDataAfterRequestingItsTurn(top);
    testMyTurnClearsRequestAndMakesReadyForNextAddress(top);
    testRepeatedWriteSetsFull(top);

    testReaderStartsNotRequesting(top);
    testAfterAddressReaderRequestsTurn(top);
    testReaderKeepsAddressWhileNotTurn(top);
    testReaderTransmitsDataStartingOnSameCycle(top);
    testReaderAdvancesDataOnRead(top);
    testStallingReadeKeepsExistingData(top);
    testReaderRepeatedAccessWorks(top);

    testInitialWriteRequiresRead(top);
    testAfterResponseTaggerReadDone(top);
    testWriteConflictReadsAndWritesDuplicate(top);
    testReadOfFetchedAddressReadsFromCache(top);
    testCapacityReadOverwritesOldest(top);
    testHitReadMarksAsMoreReccent(top);
    testMidtermReadDoesNotTrickCounts(top);

    readThenWriteOverridesDataInSameLine(top);
    testHitWriteMarksAsMoreReccent(top);
    testBlankWriteOverridesWithoutFetch(top);
    testWritingAllowsForReadLater(top);
    testWrittenLinesFlushedOnConflict(top);
    testWrittenLinesFlushedOnConflictWrite(top);
    testReadAfterWriteDoesNotMarkAsNonDirty(top);

    delete top;

    std::chrono::high_resolution_clock::time_point end_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> total_time = end_time - start_time;
    double s_real = total_time.count();
    int ns_sim_per_s = (int)(NANOS / s_real);
    std::cout << "Finished " << NANOS << "ns simulation in " << s_real << "s at " << ns_sim_per_s << "ns/s." << std::endl;
    exit(0);
}

void clk(Vl2_tb *dut)
{
    dut->eval();
    dut->clk = 1;
    NANOS += 5;
    dut->eval();

    dut->clk = 0;
    NANOS += 5;
    dut->eval();
}

double sc_time_stamp()
{
    return NANOS * 1000;
}
